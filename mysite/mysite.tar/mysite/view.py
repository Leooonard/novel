#-*-coding:utf8-*-
from django.http import HttpResponse
from django.template.loader import get_template
from django.shortcuts import render_to_response
from django.core.context_processors import csrf
from django.template import context
from ctypes import *
from django.utils import simplejson
from xml.etree.ElementTree import ElementTree
from xml.etree.ElementTree import Element
from xml.etree.ElementTree import SubElement
from xml.etree.ElementTree import dump
from xml.etree.ElementTree import Comment
from xml.etree.ElementTree import tostring
import os, ctypes, MySQLdb


class pingpac:
	dataNum= 'null'
	Length= 'null'
	proto= 'null'
	srcIP= 'null'
	dstIP= 'null'
	info= 'null'

def findExpNameFromExpType(Type):
	if(Type== '01'):
		s= '静态路由实验'
		return s
	else:
		return 'error'

def admin(request):
	Acc= request.POST.get('ACC')
	Pwd= request.POST.get('PWD')
	conn= MySQLdb.connect(host= 'localhost', user= 'root', passwd= '', db= 'LabOL')
	cur= conn.cursor()
	cur.execute('select * from exp_info')
	result= cur.fetchall()
	JSONStr= '['
	count= 0
	while count< len(result):
		ID= result[count][3]
		Type= result[count][1]
		Name= findExpNameFromExpType(Type)
		Date= result[count][2]
		JSONStr= JSONStr+ '{"ID":"'+ ID+ '","Name":"'+ Name+ '","ExpDate":"'+ Date+ '"},'
		count= count+ 1
	JSONStr= JSONStr[0: len(JSONStr)- 1]
	if(len(JSONStr)== 0):
		JSONStr= '['
	JSONStr= JSONStr+ ']'
	fd= open('/home/mymmoondt/mysite/mysite/text', 'w')
	fd.write(Acc+Pwd)
	fd.close()
	c= {'ACC': Acc, 'PWD': Pwd, 'INITSTR': JSONStr}
	c.update(csrf(request))
	cur.close()
	conn.close()
	return render_to_response('admin.html', c)

def Login(request):
	if(request.POST.get('flag', False)== False):
		c= {}
		c.update(csrf(request))
		return render_to_response('Login.html', c)
	else:
		acc= request.POST.get('accInfo')
		pwd= request.POST.get('pwdInfo')
		conn= MySQLdb.connect(host= 'localhost', user= 'root', passwd= '', db= 'LabOL')
		cursor= conn.cursor()
		cursor.execute('select * from user_info where ID='+ acc)
		result= cursor.fetchall()
		if(len(result)== 0):
			cursor.close()
			conn.close()	
			c= {'RESULT': 1, 'RELOAD': 1}
			c.update(csrf(request))
			return render_to_response('Login.html', c)
		elif(result[0][1]!= pwd):
			cursor.close()
			conn.close()
			c= {'RESULT': 2, 'RELOAD': 1}
			c.update(csrf(request))
			return render_to_response('Login.html', c)
		else:
			if(result[0][2]== 'stu'):
				c= {'STU_JUMP': 1, 'ACC': result[0][0], 'PWD': result[0][1]}
				c.update(csrf(request))
				return render_to_response('Login.html', c)
			elif(result[0][2]== 'tea'):
				c= {'TEA_JUMP': 1, 'ACC': result[0][0], 'PWD': result[0][1]}
				c.update(csrf(request))
				return render_to_response('Login.html', c)

def Register(request):
	if(request.POST.get('flag', False)== False):	
		c= {}
		c.update(csrf(request))
		return render_to_response('Register.html', c)
	else:
		acc= request.POST.get('accInfo')
		pwd= request.POST.get('pwdInfo')
		conn= MySQLdb.connect(host= 'localhost', user= 'root', passwd= '', db= 'LabOL')
		cursor= conn.cursor()
		cursor.execute('select * from user_info where ID='+ acc)
		result= cursor.fetchall()
		if(len(result)!= 0):
			cursor.close()
			conn.close()	
			c= {'SUCCESS': False, 'RELOAD': 1}
			c.update(csrf(request))
			return render_to_response('Register.html', c)
		else:
			cursor.execute('insert into user_info values(%s,%s,%s)', (acc, pwd, 'stu'))
			conn.commit()
			cursor.close()
			conn.close()
			c= {'SUCCESS': True, 'RELOAD': 1}
			c.update(csrf(request))
			return render_to_response('Register.html', c)

def TeacherSetting(request):
	c= {}
	c.update(csrf(request))
	return render_to_response('TeacherSetting.html', c)	

def PersonalSetting(request):
	Acc= request.POST.get('ACC')
	Pwd= request.POST.get('PWD')
	CHPWDFLAG= request.POST.get('CHPWDFLAG', False)
	conn= MySQLdb.connect(host= 'localhost', user= 'root', passwd= '', db= 'LabOL')
	cur= conn.cursor()
	cur.execute('select * from stu_exp_info where ID=%s', (Acc))
	result= cur.fetchall()
	count= 0
	JSONStr= '['
	while count< len(result):
		exp_type= result[count][1]
		exp_content= result[count][2]
		exp_report= result[count][3]
		exp_grade= result[count][4]
		exp_id= result[count][5]
		JSONStr= JSONStr+ '{"TYPE":"'+ exp_type+ '","CONTENT":'
		if(exp_content!= 'NULL' and exp_content!= 'None' and exp_content!= None):
			JSONStr= JSONStr+ 'true,"REPORT":'
		else:
			JSONStr= JSONStr+ 'false,"REPORT":'
		if(exp_report!= None and exp_report!= 'None' and exp_report!= 'NULL'):
			JSONStr= JSONStr+ 'true,"GRADE":"'
		else:
			JSONStr= JSONStr+ 'false,"GRADE":"'
		if(exp_grade== 'NULL' or exp_grade== 'None' or exp_grade== None):
			JSONStr= JSONStr+ 'NULL","ID":"'
		else:
			JSONStr= JSONStr+ exp_grade+ '","ID":"'
		JSONStr= JSONStr+ exp_id+ '"},'
		count= count+ 1
	JSONStr= JSONStr[0: len(JSONStr)- 1]
	if(len(JSONStr)== 0):
		JSONStr= '['
	JSONStr= JSONStr+ ']' 
	if(CHPWDFLAG):
		cur.execute('update user_info set pwd=%s where ID=%s', (Pwd, Acc))
		conn.commit()
		cur.close()
		conn.close()
		c= {'UPDATE': 1, 'ACC': Acc, 'PWD': Pwd, 'JSONStr': JSONStr}
		c.update(csrf(request))
		return render_to_response('PersonalSetting.html', c)
	else:
		c= {'ACC': Acc, 'PWD': Pwd, 'JSONStr': JSONStr}
		c.update(csrf(request))
		cur.close()
		conn.close()
		return render_to_response('PersonalSetting.html', c)

def readPCAP(trace):
	libping= cdll.LoadLibrary('/home/mymmoondt/mysite/mysite/libpcap.so')
	result= ctypes.string_at(libping.checkPCAP(trace))
	pcapArr= []
	findex= 0
	lindex= 0
	while result[lindex]!= '$':
		count= 0
		x= pingpac()
		while count< 6:
			if(count== 0):
				if(result[lindex]== '|'):
					x.dataNum= result[findex: lindex]
					findex= lindex+ 1
					lindex= lindex+ 1
					count= count+ 1
				else:
					lindex= lindex+ 1
			elif(count== 1):
				if(result[lindex]== '|'):
					x.Length= result[findex: lindex]
					findex= lindex+ 1
					lindex= lindex+ 1
					count= count+ 1
				else:
					lindex= lindex+ 1
			elif(count== 2):
				if(result[lindex]== '|'):
					x.proto= result[findex: lindex]
					findex= lindex+ 1
					lindex= lindex+ 1
					count= count+ 1
					if(x.proto== "ARP"):
						x.srcIP= "null"
						x.dstIP= "null"
						x.info= "null"
						count= 6
				else:
					lindex= lindex+ 1
			elif(count== 3):
				if(result[lindex]== '|'):
					x.srcIP= result[findex: lindex]
					findex= lindex+ 1
					lindex= lindex+ 1
					count= count+ 1
				else:
					lindex= lindex+ 1
			elif(count== 4):
				if(result[lindex]== '|'):
					x.dstIP= result[findex: lindex]
					findex= lindex+ 1
					lindex= lindex+ 1
					count= count+ 1
				else:
					lindex= lindex+ 1
			elif(count== 5):
				if(result[lindex]== '|'):
					x.info= result[findex: lindex]
					findex= lindex+ 1
					lindex= lindex+ 1
					count= count+ 1
				else:
					lindex= lindex+ 1
		pcapArr.append(x)
	return pcapArr

def PingExp(request):
	showTable= request.POST.get('sExp', 'false')
	if(showTable== 'true'):
		libping= cdll.LoadLibrary('/home/mymmoondt/mysite/mysite/libping.so')
		result= ctypes.string_at(libping.checkPCAP('/home/mymmoondt/mysite/mysite/ping.pcap'))
		pcapArr= []
		findex= 0
		lindex= 0
		while result[lindex]!= '$':
			count= 0
			x= pingpac()
			while count< 6:
				if(count== 0):
					if(result[lindex]== '|'):
						x.dataNum= result[findex: lindex]
						findex= lindex+ 1
						lindex= lindex+ 1
						count= count+ 1
					else:
						lindex= lindex+ 1
				elif(count== 1):
					if(result[lindex]== '|'):
						x.Length= result[findex: lindex]
						findex= lindex+ 1
						lindex= lindex+ 1
						count= count+ 1
					else:
						lindex= lindex+ 1
				elif(count== 2):
					if(result[lindex]== '|'):
						x.proto= result[findex: lindex]
						findex= lindex+ 1
						lindex= lindex+ 1
						count= count+ 1
						if(x.proto== "ARP"):
							x.srcIP= "null"
							x.dstIP= "null"
							x.info= "null"
							count= 6
					else:
						lindex= lindex+ 1
				elif(count== 3):
					if(result[lindex]== '|'):
						x.srcIP= result[findex: lindex]
						findex= lindex+ 1
						lindex= lindex+ 1
						count= count+ 1
					else:
						lindex= lindex+ 1
				elif(count== 4):
					if(result[lindex]== '|'):
						x.dstIP= result[findex: lindex]
						findex= lindex+ 1
						lindex= lindex+ 1
						count= count+ 1
					else:
						lindex= lindex+ 1
				elif(count== 5):
					if(result[lindex]== '|'):
						x.info= result[findex: lindex]
						findex= lindex+ 1
						lindex= lindex+ 1
						count= count+ 1
					else:
						lindex= lindex+ 1
			pcapArr.append(x)
		context= {'showTable': 1, 'pcapPack': pcapArr}
		context.update(csrf(request))		
		return render_to_response('PingExp.html', context)
	elif(showTable== 'false'):
		context= {}
		context.update(csrf(request))		
		return render_to_response('PingExp.html', context)

def RouteExp(request):
	fd= open('/home/mymmoondt/mysite/templates/RouteExp.html')
	html= fd.read()
	fd.close()
	return HttpResponse(html)

def DynamicRouteExp(request):
	exp_id= request.POST.get('ID')
	Acc= request.POST.get('ACC')
	Pwd= request.POST.get('PWD') 
	op= request.POST.get('start', 'false')
	pcapArr= []
	if(op== 'true'):
		JSONObj= simplejson.loads(request.POST.get('data'))
		xmlTree= ElementTree()
		root= Element('root')
		xmlTree._setroot(root)
		ExpType= Element('experitype')
		ExpType.text= 'ROUTER'
		root.append(ExpType)
		NodeCount= Element('nodecount')
		NodeCount.text= str(JSONObj['NodeCount'])
		root.append(NodeCount)
		SegCount= Element('segmentcount')
		SegCount.text= str(len(JSONObj['DATA']))
		root.append(SegCount)
		for seg in JSONObj['DATA']:
			if(seg['ConObj1']['Type']== 'Route'):
				if(seg['ConObj1']['RouteInfo']['HostDev']):
					hNode= Element('local')
					hNode.set('ID', seg['ConObj1']['RouteID'][1: len(seg['ConObj1']['RouteID'])])
					hNode.set('type', 'router')
					root.append(hNode)
				if(seg['ConObj1']['RouteInfo']['TargetDev']):
					tNode= Element('remote')
					tNode.set('ID', seg['ConObj1']['RouteID'][1: len(seg['ConObj1']['RouteID'])])
					tNode.set('type', 'router')
					root.append(tNode)
			else:
				if(seg['ConObj1']['HostInfo']['HostDev']):
					hNode= Element('local')
					hNode.set('ID', seg['ConObj1']['HostID'][1: len(seg['ConObj1']['HostID'])])
					hNode.set('type', 'host')
					root.append(hNode)
				if(seg['ConObj1']['HostInfo']['TargetDev']):
					tNode= Element('remote')
					tNode.set('ID', seg['ConObj1']['HostID'][1: len(seg['ConObj1']['HostID'])])
					tNode.set('type', 'host')
					root.append(tNode)
			if(seg['ConObj2']['Type']== 'Route'):
				if(seg['ConObj2']['RouteInfo']['HostDev']):
					hNode= Element('local')
					hNode.set('ID', seg['ConObj2']['RouteID'][1: len(seg['ConObj2']['RouteID'])])
					hNode.set('type', 'router')
					root.append(hNode)
				if(seg['ConObj2']['RouteInfo']['TargetDev']):
					tNode= Element('remote')
					tNode.set('ID', seg['ConObj2']['RouteID'][1: len(seg['ConObj2']['RouteID'])])
					tNode.set('type', 'router')
					root.append(tNode)
			else:
				if(seg['ConObj2']['HostInfo']['HostDev']):
					hNode= Element('local')
					hNode.set('ID', seg['ConObj2']['HostID'][1: len(seg['ConObj2']['HostID'])])
					hNode.set('type', 'host')
					root.append(hNode)
				if(seg['ConObj2']['HostInfo']['TargetDev']):
					tNode= Element('remote')
					tNode.set('ID', seg['ConObj2']['HostID'][1: len(seg['ConObj2']['HostID'])])
					tNode.set('type', 'host')
					root.append(tNode)
		for seg in JSONObj['DATA']:
			segEle= Element('segment')
			segEle.set('ID', seg['segID'][1: len(seg['segID'])])
			devEle= Element('node')
			if(seg['ConObj1']['Type']== 'Host'):
				devEle.set('ID', seg['ConObj1']['HostID'][1: len(seg['ConObj1']['HostID'])])
				devEle.set('type', 'host')
				devIPEle= Element('ipaddress')
				devIPEle.text= seg['ConObj1']['HostInfo']['IP']
				devMaskIPEle= Element('mask')
				devMaskIPEle.text= seg['ConObj1']['HostInfo']['MaskIP']
				devEle.append(devIPEle)
				devEle.append(devMaskIPEle)
				segEle.append(devEle)
			elif(seg['ConObj1']['Type']== 'Route'):
				devEle.set('ID', seg['ConObj1']['RouteID'][1: len(seg['ConObj1']['RouteID'])])
				devEle.set('type', 'router')
				devIPEle= Element('ipaddress')
				devIPEle.text= seg['ConObj1']['RouteInfo']['IP']
				devMaskIPEle= Element('mask')
				devMaskIPEle.text= seg['ConObj1']['RouteInfo']['MaskIP']
				devEle.append(devIPEle)
				devEle.append(devMaskIPEle)
				devRouteTable= Element('routertable')
				rowCount= 0;
				for row in seg['ConObj1']['RouteInfo']['RouteTable']:
					rowEle= Element('item')
					rowEle.set('ID', str(rowCount))
					rowCount= rowCount+ 1
					rowIPEle= Element('destaddress')
					rowIPEle.text= row['IP']
					rowNextSkipEle= Element('nexthop')
					rowNextSkipEle.text= row['NextSkip']
					rowMaskIPEle= Element('mask')
					rowMaskIPEle.text= row['MaskIP']
					rowEle.append(rowIPEle)
					rowEle.append(rowMaskIPEle)
					rowEle.append(rowNextSkipEle)
					devRouteTable.append(rowEle)
				devEle.append(devRouteTable)
				segEle.append(devEle)
			devEle= Element('node')
			if(seg['ConObj2']['Type']== 'Host'):
				devEle.set('ID', seg['ConObj2']['HostID'][1: len(seg['ConObj2']['HostID'])])
				devEle.set('type', 'host')
				devIPEle= Element('ipaddress')
				devIPEle.text= seg['ConObj2']['HostInfo']['IP']
				devMaskIPEle= Element('mask')
				devMaskIPEle.text= seg['ConObj2']['HostInfo']['MaskIP']
				devEle.append(devIPEle)
				devEle.append(devMaskIPEle)
				segEle.append(devEle)
			elif(seg['ConObj2']['Type']== 'Route'):
				devEle.set('ID', seg['ConObj2']['RouteID'][1: len(seg['ConObj2']['RouteID'])])
				devEle.set('type', 'router')
				devIPEle= Element('ipaddress')
				devIPEle.text= seg['ConObj2']['RouteInfo']['IP']
				devMaskIPEle= Element('mask')
				devMaskIPEle.text= seg['ConObj2']['RouteInfo']['MaskIP']
				devEle.append(devIPEle)
				devEle.append(devMaskIPEle)
				devRouteTable= Element('routertable')
				rowCount= 0;
				for row in seg['ConObj2']['RouteInfo']['RouteTable']:
					rowEle= Element('item')
					rowEle.set('ID', str(rowCount))
					rowCount= rowCount+ 1
					rowIPEle= Element('destaddress')
					rowIPEle.text= row['IP']
					rowNextSkipEle= Element('nexthop')
					rowNextSkipEle.text= row['NextSkip']
					rowMaskIPEle= Element('mask')
					rowMaskIPEle.text= row['MaskIP']
					rowEle.append(rowIPEle)
					rowEle.append(rowMaskIPEle)
					rowEle.append(rowNextSkipEle)
					devRouteTable.append(rowEle)
				devEle.append(devRouteTable)
				segEle.append(devEle)
			root.append(segEle)
		xmlTree.write('/home/mymmoondt/mysite/mysite/data.xml', 'utf8')	
		libping= cdll.LoadLibrary('/home/mymmoondt/repos/ns-3-allinone/ns-3-dev/scratch/lab-ping.so')
		libping.ping('/home/mymmoondt/mysite/mysite/data')
		pcapArr= []
		pcapArr= readPCAP('/home/mymmoondt/mysite/mysite/ping-right.pcap')
		dataReturn= request.POST.get('data_save')
		flag= int(request.POST.get('FLAG'))
		flag= flag+ 1
		context= {'ACC': Acc, 'PWD': Pwd, 'ID': exp_id, 'reLoad': 1, 'JSONStr': dataReturn, 'PCAPPACK': pcapArr, 'FLAG': flag}
		context.update(csrf(request))
		return render_to_response('DynamicRouteExp.html', context)
	elif(op== 'false'):
		conn= MySQLdb.connect(host= 'localhost', user= 'root', passwd= '', db= 'LabOL')
		cur= conn.cursor()
		cur.execute('select * from stu_exp_info where ID=%s and exp_id=%s', (Acc, exp_id))
		result= cur.fetchall()
		if(len(result)!= 1):	
			context= {'ACC': Acc, 'PWD': Pwd, 'ID': exp_id}
		elif(len(result[0][2])> 0):
			context= {'ACC': Acc, 'PWD': Pwd, 'ID': exp_id, 'PRELOAD': 1, 'PRECONTENT': result[0][2]}
		else:
			context= {'ACC': Acc, 'PWD': Pwd, 'ID': exp_id}
		context.update(csrf(request))
		cur.close()
		conn.close()
		return render_to_response('DynamicRouteExp.html', context)
	elif(op== 'save'):
		Content= request.POST.get('data')
		conn= MySQLdb.connect(host= 'localhost', user= 'root', passwd= '', db= 'LabOL')
		cur= conn.cursor()
		cur.execute('select exp_content from stu_exp_info where ID=%s and exp_id=%s', (Acc, exp_id))
		result= cur.fetchall()
		if(len(result)== 0):
			cur.execute('insert into stu_exp_info values(%s,%s,%s,NULL,NULL,%s)', (Acc, exp_id[0:2], Content, exp_id))
		else:
			cur.execute('update stu_exp_info set exp_content=%s where ID=%s and exp_id= %s', (Content, Acc, exp_id))
		conn.commit()
		cur.close()
		conn.close()
		context= {'ACC': Acc, 'PWD': Pwd, 'ID': exp_id, 'reLoad': 1, 'JSONStr': Content}
		context.update(csrf(request))
		return render_to_response('DynamicRouteExp.html', context)
	elif(op== 'load'):
		Content= request.POST.get('data')
		conn= MySQLdb.connect(host= 'localhost', user= 'root', passwd= '', db= 'LabOL')
		cur= conn.cursor()
		cur.execute('select * from stu_exp_info where ID=%s and exp_id=%s', (Acc, exp_id))
		result= cur.fetchall()
		cur.close()
		conn.close()
		if(len(result)== 0 or result[0][2]== 'None' or result[0][2]== 'NULL'):
			context= {'ACC': Acc, 'PWD': Pwd, 'ID': exp_id, 'LoadDB': 0, 'FLAG': 1, 'JSONStr': Content}
			context.update(csrf(request))
			return render_to_response('DynamicRouteExp.html', context)
		else:
			context= {'ACC': Acc, 'PWD': Pwd, 'ID': exp_id, 'LoadDB': 1, 'JSONStr': result[0][2]}
			context.update(csrf(request))
			return render_to_response('DynamicRouteExp.html', context)

def DynamicRouteConfDialog(request):
	fd= open('/home/mymmoondt/mysite/templates/DynamicRouteConfDialog.html')
	html= fd.read()
	fd.close()
	return HttpResponse(html)

def DynamicHostConfDialog(request):
	fd= open('/home/mymmoondt/mysite/templates/DynamicHostConfDialog.html')
	html= fd.read()
	fd.close()
	return HttpResponse(html)

def PingHostConfDialog(request):
	fd= open('/home/mymmoondt/mysite/templates/PingHostConfDialog.html')
	html= fd.read()
	fd.close()
	return HttpResponse(html)

def PingTarConfDialog(request):
	fd= open('/home/mymmoondt/mysite/templates/PingTarConfDialog.html')
	html= fd.read()
	fd.close()
	return HttpResponse(html)

def PingRouteConfDialog(request):
	fd= open('/home/mymmoondt/mysite/templates/PingRouteConfDialog.html')
	html= fd.read()
	fd.close()
	return HttpResponse(html)

def RunPingExp(request):
	c= {}
	c.update(csrf(request))
	return render_to_response('PingHostConfDialog.html', c)

def test(request):
	c= {}
	c.update(csrf(request))
	return render_to_response('test.html', c)

def testDialog(request):
	c= {}
	c.update(csrf(request))
	return render_to_response('testDialog.html', c)
	

def RegisterProc(request):
	c= {}
	c.update(csrf(request))
	return render_to_response('Register.html', c)

























