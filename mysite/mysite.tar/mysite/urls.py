from django.conf.urls import patterns, include, url
from mysite.view import admin, PingExp, RouteExp, DynamicRouteExp, PingHostConfDialog, PingTarConfDialog, RunPingExp, PingRouteConfDialog, test, testDialog, DynamicRouteConfDialog, DynamicHostConfDialog, RegisterProc, Login, Register, PersonalSetting, TeacherSetting

# Uncomment the next two lines to enable the admin:
# from django.contrib import admin
# admin.autodiscover()

urlpatterns = patterns('',
	('^mysite/admin/$', admin),
	('^mysite/Login/$', Login),
	('^mysite/Register/$', Register),	
	('^mysite/PingExp/$', PingExp),
	('^mysite/RouteExp/$', RouteExp),
	('^mysite/DynamicRouteExp/$', DynamicRouteExp),
	('^mysite/DynamicRouteConfDialog/$', DynamicRouteConfDialog),
	('^mysite/DynamicHostConfDialog/$', DynamicHostConfDialog),
	('^mysite/PingHostConfDialog/$', PingHostConfDialog),
	('^mysite/PingTarConfDialog/$', PingTarConfDialog),
	('^mysite/RunPingExp/$', RunPingExp),
	('^mysite/test/$', test),
	('^mysite/testDialog/$', testDialog),
	('^mysite/PingRouteConfDialog/$', PingRouteConfDialog),
	('^mysite/RegisterProc/$', RegisterProc),
	('^mysite/PersonalSetting/$', PersonalSetting),
	('^mysite/TeacherSetting/$', TeacherSetting),
)
